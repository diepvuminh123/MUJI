<?php $GLOBALS['site_info'] = $site_info; ?>
<?php include 'Template/Header.php'; ?>


<!-- Nội dung trang chủ -->
<h1 class="text-2xl font-bold">Chào mừng đến với MUJI</h1>

<?php include 'Template/Footer.php'; ?>
